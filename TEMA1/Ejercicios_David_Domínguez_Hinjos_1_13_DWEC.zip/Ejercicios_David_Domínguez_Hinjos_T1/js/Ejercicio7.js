let array = [2, 4, 6, 8, 2, 4, 6, 9];
console.log((array.every(n => n % 2 === 0)) ? "Todos son pares" : "No todos son pares hay algún impar");